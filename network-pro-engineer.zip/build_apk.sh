#!/usr/bin/env bash
set -e

echo "==================================================="
echo "    بناء تطبيق مصر رادار الشبكات (Egypt Network Radar)"
echo "            تحويل المشروع إلى ملف APK"
echo "==================================================="
echo ""

# 1. Prepare .env
[ -f .env ] || touch .env

# 2. Prepare debug.keystore
if [ ! -f "debug.keystore" ]; then
    if [ -f "debug.keystore.base64" ]; then
        base64 -d debug.keystore.base64 > debug.keystore 2>/dev/null || true
    fi
fi

# 3. Grant gradlew execution rights
chmod +x gradlew

# 4. Build debug APK
echo "جاري تجميع وبناء ملف الـ APK..."
./gradlew assembleDebug --no-daemon

echo ""
echo "==================================================="
echo " تم بناء وتوليد ملف الـ APK بنجاح!"
echo " المسار: app/build/outputs/apk/debug/app-debug.apk"
echo "==================================================="
