package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AvailableNetwork
import com.example.ui.theme.EgyptDarkSurface
import com.example.ui.theme.EgyptGold
import com.example.ui.theme.EgyptRed
import com.example.ui.theme.EgyptWhite
import com.example.ui.theme.OperatorEtisalat
import com.example.ui.theme.OperatorOrange
import com.example.ui.theme.OperatorVodafone
import com.example.ui.theme.OperatorWE
import com.example.ui.theme.SignalGreen

@Composable
fun NetScanDialog(
    isOpen: Boolean,
    networks: List<AvailableNetwork>,
    onDismiss: () -> Unit,
    onLockNetwork: (mccMnc: String) -> Unit
) {
    if (!isOpen) return

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = EgyptDarkSurface,
        shape = RoundedCornerShape(16.dp),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Radar,
                    contentDescription = null,
                    tint = EgyptGold
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "تعرف على الشبكة (NetScan)",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = EgyptWhite
                )
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "تم رصد أقوى 5 شبكات خلوية في موقعك الحالي. يمكنك تثبيت الشبكة يدوياً لتفضيل مشغل معين أو تفعيل التجوال المحلي الوهمي.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFA0A0A0)
                )

                Spacer(modifier = Modifier.height(12.dp))

                networks.forEach { net ->
                    val opColor = when {
                        net.operatorNameAr.contains("فودافون") -> OperatorVodafone
                        net.operatorNameAr.contains("أورانج") -> OperatorOrange
                        net.operatorNameAr.contains("اتصالات") -> OperatorEtisalat
                        net.operatorNameAr.contains("المصرية") || net.operatorNameAr.contains("وي") -> OperatorWE
                        else -> EgyptGold
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .background(Color(0xFF16161B), RoundedCornerShape(10.dp))
                            .border(
                                width = if (net.isConnected || net.isManualLocked) 1.5.dp else 0.5.dp,
                                color = if (net.isManualLocked) EgyptGold else if (net.isConnected) SignalGreen else Color(0xFF333333),
                                shape = RoundedCornerShape(10.dp)
                            )
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .background(opColor, CircleShape)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = net.operatorNameAr,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.Bold
                                    ),
                                    color = EgyptWhite
                                )
                                Text(
                                    text = "${net.networkType} | ${net.signalDbm} dBm (${net.signalQuality})",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF90CAF9)
                                )
                            }
                        }

                        if (net.isManualLocked) {
                            Box(
                                modifier = Modifier
                                    .background(EgyptGold.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 6.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = "مثبتة يدوياً",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = EgyptGold
                                )
                            }
                        } else if (net.isConnected) {
                            Box(
                                modifier = Modifier
                                    .background(SignalGreen.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 6.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = "متصل حالياً",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = SignalGreen
                                )
                            }
                        } else {
                            OutlinedButton(
                                onClick = { onLockNetwork(net.mccMnc) },
                                shape = RoundedCornerShape(6.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, EgyptGold)
                            ) {
                                Text("تثبيت", color = EgyptGold, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = EgyptRed)
            ) {
                Text("إغلاق", color = Color.White)
            }
        }
    )
}
