package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.SimCard
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EgyptDarkSurface
import com.example.ui.theme.EgyptGold
import com.example.ui.theme.EgyptWhite
import com.example.ui.theme.OperatorEtisalat
import com.example.ui.theme.OperatorOrange
import com.example.ui.theme.OperatorVodafone
import com.example.ui.theme.OperatorWE

@Composable
fun OperatorBadge(
    operatorArabicName: String,
    operatorEnglishName: String,
    simPhoneNumber: String,
    mccMnc: String,
    networkGen: String,
    modifier: Modifier = Modifier
) {
    val operatorColor = when {
        operatorArabicName.contains("فودافون") || operatorEnglishName.contains("Vodafone", ignoreCase = true) -> OperatorVodafone
        operatorArabicName.contains("أورانج") || operatorEnglishName.contains("Orange", ignoreCase = true) -> OperatorOrange
        operatorArabicName.contains("اتصالات") || operatorEnglishName.contains("Etisalat", ignoreCase = true) -> OperatorEtisalat
        operatorArabicName.contains("المصرية") || operatorArabicName.contains("وي") || operatorEnglishName.contains("WE", ignoreCase = true) -> OperatorWE
        else -> OperatorVodafone
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = EgyptDarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, operatorColor.copy(alpha = 0.4f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .background(operatorColor, shape = CircleShape)
                            .border(2.dp, EgyptGold, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.SimCard,
                            contentDescription = "SIM",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = operatorArabicName,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp
                                ),
                                color = EgyptWhite
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.Default.Verified,
                                contentDescription = "موثق",
                                tint = EgyptGold,
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        Text(
                            text = operatorEnglishName,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFA0A0A0)
                        )
                    }
                }

                // Network generation pill (e.g. 4G LTE+ or 5G)
                Box(
                    modifier = Modifier
                        .background(operatorColor.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                        .border(1.dp, operatorColor, RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = networkGen,
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold
                        ),
                        color = EgyptWhite
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // SIM Details Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF141418), RoundedCornerShape(10.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.PhoneAndroid,
                        contentDescription = "رقم الشريحة",
                        tint = EgyptGold,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "رقم الشريحة: $simPhoneNumber",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.SemiBold
                        ),
                        color = EgyptWhite
                    )
                }

                Text(
                    text = "MCC/MNC: $mccMnc",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFFB0B0B0)
                )
            }
        }
    }
}
