package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.EgyptGeoData
import com.example.ui.DashboardViewModel
import com.example.ui.components.DigitalIdCard
import com.example.ui.theme.EgyptDarkSurface
import com.example.ui.theme.EgyptGold
import com.example.ui.theme.EgyptRed
import com.example.ui.theme.EgyptWhite
import com.example.ui.theme.OperatorEtisalat
import com.example.ui.theme.OperatorOrange
import com.example.ui.theme.OperatorVodafone
import com.example.ui.theme.OperatorWE
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SearchScreen(
    viewModel: DashboardViewModel,
    modifier: Modifier = Modifier
) {
    val searchQuery by viewModel.phoneSearchQuery.collectAsState()
    val analysisResult by viewModel.currentPhoneAnalysis.collectAsState()
    val lookupsHistory by viewModel.numberLookups.collectAsState()
    val focusManager = LocalFocusManager.current

    val sampleChips = listOf(
        "01098765432" to "فودافون",
        "01123456789" to "اتصالات",
        "01287654321" to "أورانج",
        "01555544433" to "المصرية WE",
        "0225789012" to "أرضي القاهرة",
        "035467890" to "أرضي الإسكندرية"
    )

    // Check if search query matches an Egyptian governorate or district
    val matchingGov = remember(searchQuery) {
        if (searchQuery.isNotBlank()) {
            EgyptGeoData.findGovernorate(searchQuery)
        } else null
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0C0C10))
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header Section
        item {
            Column {
                Text(
                    text = "رادار الهوية الرقمية والسنترالات",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 24.sp
                    ),
                    color = EgyptGold
                )
                Text(
                    text = "استعلام فوري عن المشغل والسنترال والمحافظة التابعة لأي رقم في مصر",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFFA0A0A0)
                )
            }
        }

        // Search Input Box & Submit Button
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = EgyptDarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2C2C35))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { viewModel.updatePhoneSearchQuery(it) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("search_input"),
                        placeholder = {
                            Text(
                                "أدخل رقم الهاتف أو الأرضي (مثال: 010... أو 02...)",
                                fontSize = 13.sp,
                                color = Color.Gray
                            )
                        },
                        leadingIcon = {
                            Icon(Icons.Default.Search, contentDescription = null, tint = EgyptGold)
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { viewModel.updatePhoneSearchQuery("") }) {
                                    Icon(Icons.Default.Clear, contentDescription = "مسح", tint = Color.LightGray)
                                }
                            }
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Phone,
                            imeAction = ImeAction.Search
                        ),
                        keyboardActions = KeyboardActions(
                            onSearch = {
                                focusManager.clearFocus()
                                viewModel.performPhoneSearch()
                            }
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = EgyptGold,
                            unfocusedBorderColor = Color(0xFF40404C),
                            focusedTextColor = EgyptWhite,
                            unfocusedTextColor = EgyptWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            focusManager.clearFocus()
                            viewModel.performPhoneSearch()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("btn_search"),
                        colors = ButtonDefaults.buttonColors(containerColor = EgyptRed),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Search, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "فحص الرقم واستخراج السنترال",
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Quick Chips
                    Text(
                        text = "نماذج سريعة للتجربة:",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        sampleChips.forEach { (number, label) ->
                            Box(
                                modifier = Modifier
                                    .background(Color(0xFF202028), RoundedCornerShape(20.dp))
                                    .border(1.dp, Color(0xFF333340), RoundedCornerShape(20.dp))
                                    .clickable {
                                        viewModel.updatePhoneSearchQuery(number)
                                        viewModel.performPhoneSearch(number)
                                    }
                                    .padding(horizontal = 10.dp, vertical = 5.dp)
                            ) {
                                Text(
                                    text = "$label: $number",
                                    fontSize = 11.sp,
                                    color = EgyptGold,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }
        }

        // Search Result (Digital ID Card)
        if (analysisResult != null) {
            item {
                DigitalIdCard(analysis = analysisResult!!)
            }
        }

        // Matching Egyptian Governorate / Demographic Information
        if (matchingGov != null) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF171720)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, EgyptGold)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.LocationCity,
                                    contentDescription = null,
                                    tint = EgyptGold,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "محافظة ${matchingGov.nameAr} (${matchingGov.nameEn})",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = EgyptWhite
                                )
                            }
                            Text(
                                text = "كود: ${matchingGov.landlinePrefix}",
                                color = EgyptGold,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "العاصمة: ${matchingGov.capital} | المساحة: ${matchingGov.areaKm2} كم²",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFAAAAAA)
                        )
                        Text(
                            text = "عدد السكان التقديري: %,d نسمة".format(Locale.US, matchingGov.population),
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                            color = EgyptWhite
                        )
                        Text(
                            text = "أبراج الاتصالات المقدرة بالمحافظة: ~${matchingGov.estimatedTowers} برج محمول",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF80D8FF)
                        )
                        Text(
                            text = "أبرز المراكز والأحياء: ${matchingGov.topDistricts.joinToString("، ")}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFFFD54F)
                        )
                    }
                }
            }
        }

        // Search History Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = null,
                        tint = EgyptGold,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "سجل عمليات الفحص السابقة",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = EgyptWhite
                    )
                }

                if (lookupsHistory.isNotEmpty()) {
                    TextButton(onClick = { viewModel.clearNumberLookups() }) {
                        Text("مسح السجل", color = EgyptRed, fontSize = 12.sp)
                    }
                }
            }
        }

        if (lookupsHistory.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "لا توجد عمليات بحث مسجلة حتى الآن",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                }
            }
        } else {
            items(lookupsHistory) { item ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            viewModel.updatePhoneSearchQuery(item.phoneNumber)
                            viewModel.performPhoneSearch(item.phoneNumber)
                        },
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF16161D))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(EgyptGold.copy(alpha = 0.15f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Phone,
                                    contentDescription = null,
                                    tint = EgyptGold,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "${item.phoneNumber} - ${item.estimatedName}",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    color = EgyptWhite
                                )
                                Text(
                                    text = "${item.operatorName} | ${item.governorate} (${item.centralOffice})",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFFA0A0A0)
                                )
                            }
                        }

                        IconButton(onClick = { viewModel.deleteNumberLookup(item.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Gray, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }
}
