package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CellTower
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SignalCellularAlt
import androidx.compose.material.icons.filled.SimCard
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import com.example.utils.NetworkUtils
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.NeighborCell
import com.example.data.model.NetworkTelemetry
import com.example.ui.theme.SignalOrange
import com.example.ui.theme.TelecomCyan
import java.util.Locale

@Composable
fun NetworkDetailsScreen(
    telemetry: NetworkTelemetry,
    onRefreshIp: () -> Unit,
    modifier: Modifier = Modifier
) {
    val cell = telemetry.servingCell

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // IP Addresses Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Language, contentDescription = null, tint = TelecomCyan)
                            Text(
                                text = "عناوين بروتوكول الإنترنت (IP)",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }

                        IconButton(onClick = onRefreshIp) {
                            Icon(Icons.Default.Refresh, contentDescription = "تحديث IP", tint = TelecomCyan)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MetricItem(
                            label = stringResource(R.string.metric_local_ip),
                            value = telemetry.localIp,
                            isCode = true
                        )
                        MetricItem(
                            label = stringResource(R.string.metric_public_ip),
                            value = telemetry.publicIp,
                            isCode = true
                        )
                    }
                }
            }
        }

        // Link Bandwidth Throughput Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Speed, contentDescription = null, tint = TelecomCyan)
                        Text(
                            text = "سعة نقل البيانات التقديرية (Bandwidth)",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        val downMbps = (telemetry.downlinkBandwidthKbps / 1000.0)
                        val upMbps = (telemetry.uplinkBandwidthKbps / 1000.0)

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Download, contentDescription = null, tint = Color(0xFF00E676), modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            MetricItem(
                                label = stringResource(R.string.metric_download_bw),
                                value = if (downMbps > 0) String.format(Locale.US, "%.1f م.بت/ث", downMbps) else "غير محدد"
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Upload, contentDescription = null, tint = Color(0xFF00B0FF), modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            MetricItem(
                                label = stringResource(R.string.metric_upload_bw),
                                value = if (upMbps > 0) String.format(Locale.US, "%.1f م.بت/ث", upMbps) else "غير محدد"
                            )
                        }
                    }
                }
            }
        }

        // SIM & Operator Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.SimCard, contentDescription = null, tint = TelecomCyan)
                        Text(
                            text = "بيانات شريحة SIM والمشغل",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MetricItem(
                            label = "حالة شريحة SIM",
                            value = telemetry.simState
                        )
                        MetricItem(
                            label = stringResource(R.string.metric_roaming),
                            value = if (telemetry.isRoaming) "نشط (Roaming)" else "معطل (محلي)"
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MetricItem(
                            label = "كود الدولة (MCC)",
                            value = cell?.mcc ?: "424"
                        )
                        MetricItem(
                            label = "كود الشبكة (MNC)",
                            value = cell?.mnc ?: "01"
                        )
                    }
                }
            }
        }

        // Neighbor Cells Header
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.CellTower, contentDescription = null, tint = SignalOrange)
                Text(
                    text = stringResource(R.string.header_neighbor_cells) + " (${telemetry.neighborCells.size})",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }
        }

        // Neighbor Cells List
        if (telemetry.neighborCells.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Text(
                        text = "لم يتم رصد خلايا مجاورة في هذا الموقع حالياً.",
                        modifier = Modifier.padding(16.dp),
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                }
            }
        } else {
            items(telemetry.neighborCells) { neighbor ->
                NeighborCellCard(neighbor = neighbor)
            }
        }

        // Full Raw Engineering Telemetry Table
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "البيانات الخام الكاملة (Raw RF Telemetry)",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    val rawItems = listOf(
                        "Serving Cell ID (Dec)" to (cell?.cellIdDec?.toString() ?: "N/A"),
                        "Serving Cell ID (Hex)" to (cell?.cellIdHex ?: "N/A"),
                        "Physical Cell ID (PCI)" to (cell?.pci?.toString() ?: "N/A"),
                        "Tracking Area Code (TAC/LAC)" to (cell?.tacOrLac?.toString() ?: "N/A"),
                        "EARFCN Channel" to (cell?.earfcn?.toString() ?: "N/A"),
                        "Reference Signal Received Power (RSRP)" to "${cell?.rsrp ?: -120} dBm",
                        "Reference Signal Received Quality (RSRQ)" to "${cell?.rsrq ?: -12} dB",
                        "Signal-to-Interference-plus-Noise Ratio (SINR)" to "${cell?.rssnr ?: 15.0} dB",
                        "Channel Quality Indicator (CQI)" to "${cell?.cqi ?: 12} / 15",
                        "Arbitrary Strength Unit (ASU)" to "${cell?.asu ?: 0}",
                        "Calculated Downlink Frequency" to "${cell?.frequencyMhz ?: 1800.0} MHz",
                        "Frequency 3GPP Band" to (cell?.bandName ?: "N/A"),
                        "Distance Calculation Method" to telemetry.distanceMethod,
                        "Estimated Tower Distance" to NetworkUtils.formatDistanceArabic(telemetry.distanceMeters)
                    )

                    rawItems.forEachIndexed { idx, (k, v) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = k,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 11.sp
                                ),
                                modifier = Modifier.weight(1.3f)
                            )
                            Text(
                                text = v,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontSize = 11.sp
                                ),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }
    }
}

@Composable
fun NeighborCellCard(neighbor: NeighborCell) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "برج مجاور (PCI: ${neighbor.pci})",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "EARFCN: ${neighbor.earfcn} | نوع: ${neighbor.networkType}",
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${neighbor.rsrp} dBm",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = TelecomCyan
                    )
                )
                Text(
                    text = neighbor.signalQuality,
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp)
                )
            }
        }
    }
}

@Composable
fun MetricItem(
    label: String,
    value: String,
    isCode: Boolean = false,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Bold,
                fontFamily = if (isCode) FontFamily.Monospace else FontFamily.Default
            ),
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
