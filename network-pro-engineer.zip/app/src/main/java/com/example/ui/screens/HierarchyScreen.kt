package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CellTower
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.GovernorateEntity
import com.example.data.model.EgyptGeoData
import com.example.ui.DashboardViewModel
import com.example.ui.theme.EgyptDarkSurface
import com.example.ui.theme.EgyptGold
import com.example.ui.theme.EgyptRed
import com.example.ui.theme.EgyptWhite
import java.util.Locale

@Composable
fun HierarchyScreen(
    viewModel: DashboardViewModel,
    modifier: Modifier = Modifier
) {
    val governoratesFromDb by viewModel.governoratesList.collectAsState()
    var filterQuery by remember { mutableStateOf("") }
    var expandedGovId by remember { mutableStateOf<Int?>(null) }

    val activeList = if (governoratesFromDb.isNotEmpty()) {
        governoratesFromDb
    } else {
        // Fallback to static model if DB is still populating
        EgyptGeoData.GOVERNORATES.map { g ->
            GovernorateEntity(
                id = g.id,
                nameAr = g.nameAr,
                nameEn = g.nameEn,
                capital = g.capital,
                population = g.population,
                areaKm2 = g.areaKm2,
                centersCount = g.centersCount,
                landlinePrefix = g.landlinePrefix,
                estimatedTowers = g.estimatedTowers,
                topDistrictsCsv = g.topDistricts.joinToString("، "),
                centerLat = g.centerLat,
                centerLon = g.centerLon
            )
        }
    }

    val filteredList = remember(filterQuery, activeList) {
        if (filterQuery.isBlank()) activeList
        else activeList.filter {
            it.nameAr.contains(filterQuery, ignoreCase = true) ||
                    it.nameEn.contains(filterQuery, ignoreCase = true) ||
                    it.topDistrictsCsv.contains(filterQuery, ignoreCase = true) ||
                    it.capital.contains(filterQuery, ignoreCase = true)
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0C0C10))
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Column {
                Text(
                    text = "دليل مصر السكاني والشبكات",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp
                    ),
                    color = EgyptGold
                )
                Text(
                    text = "بيانات جمهورية مصر العربية: المحافظات الـ 27 والمراكز والتعداد السكاني وتوزيع الأبراج",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFA0A0A0)
                )
            }
        }

        // Summary KPI Banner
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = EgyptDarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, EgyptGold.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Public, contentDescription = null, tint = EgyptGold)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "إحصائيات الدولة الإجمالية",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = EgyptWhite
                            )
                        }
                        Text("27 محافظة", color = EgyptGold, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        KpiMiniBox(
                            title = "تعداد السكان بالداخل",
                            value = "106.5 مليون",
                            subtitle = "+ 12 مليون بالخارج",
                            icon = Icons.Default.Groups,
                            color = EgyptGold,
                            modifier = Modifier.weight(1f)
                        )
                        KpiMiniBox(
                            title = "أبراج المحمول المقدرة",
                            value = "~48,500 برج",
                            subtitle = "فودافون/أورانج/اتصالات/وي",
                            icon = Icons.Default.CellTower,
                            color = EgyptRed,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Search in Governorates and Districts
        item {
            OutlinedTextField(
                value = filterQuery,
                onValueChange = { filterQuery = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("ابحث عن محافظة، مركز، حي، أو كود سنترال...", fontSize = 13.sp, color = Color.Gray) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = EgyptGold) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = EgyptGold,
                    unfocusedBorderColor = Color(0xFF33333E),
                    focusedTextColor = EgyptWhite,
                    unfocusedTextColor = EgyptWhite
                )
            )
        }

        // List of Governorates
        items(filteredList, key = { it.id }) { gov ->
            val isExpanded = expandedGovId == gov.id

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expandedGovId = if (isExpanded) null else gov.id },
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF16161D)),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isExpanded) EgyptGold else Color(0xFF262630)
                )
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .background(EgyptGold.copy(alpha = 0.15f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${gov.id}",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = EgyptGold
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "محافظة ${gov.nameAr}",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = EgyptWhite
                                )
                                Text(
                                    text = "${gov.nameEn} | العاصمة: ${gov.capital}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFFA0A0A0)
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .background(Color(0xFF242430), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = "كود: ${gov.landlinePrefix}",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = EgyptGold
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = null,
                                tint = Color.LightGray
                            )
                        }
                    }

                    // Key Stats Quick Strip
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF111116), RoundedCornerShape(8.dp))
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        StatLabelValue("السكان", "%,d".format(Locale.US, gov.population))
                        StatLabelValue("المساحة", "${gov.areaKm2} كم²")
                        StatLabelValue("المراكز", "${gov.centersCount}")
                        StatLabelValue("الأبراج", "~${gov.estimatedTowers}")
                    }

                    // Expanded Details (Districts & Engineering Info)
                    AnimatedVisibility(visible = isExpanded) {
                        Column(modifier = Modifier.padding(top = 12.dp)) {
                            Text(
                                text = "أبرز المراكز والأحياء التابعة:",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = EgyptGold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = gov.topDistrictsCsv,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFFE0E0E0),
                                lineHeight = 18.sp
                            )

                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "الإحداثيات المركزية: ${gov.centerLat} N , ${gov.centerLon} E",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.Gray
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun KpiMiniBox(
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(Color(0xFF14141A), RoundedCornerShape(10.dp))
            .border(1.dp, Color(0xFF24242F), RoundedCornerShape(10.dp))
            .padding(10.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(title, style = MaterialTheme.typography.labelSmall, color = Color.LightGray)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = EgyptWhite)
            Text(subtitle, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
        }
    }
}

@Composable
private fun StatLabelValue(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
        Text(value, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = EgyptWhite)
    }
}
