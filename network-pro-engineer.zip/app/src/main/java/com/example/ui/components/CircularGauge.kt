package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.SignalGreen
import com.example.ui.theme.SignalOrange
import com.example.ui.theme.SignalRed
import com.example.ui.theme.SignalYellow
import com.example.utils.NetworkUtils
import kotlin.math.cos
import kotlin.math.sin

/**
 * Circular Dial Gauge for RSRP cellular signal strength.
 * Valid scale: -140 dBm (Very Poor) to -44 dBm (Excellent).
 */
@Composable
fun CircularGauge(
    rsrpDbm: Int,
    modifier: Modifier = Modifier
) {
    // Clamp RSRP to gauge range
    val clamped = rsrpDbm.coerceIn(-140, -44)
    // Fraction from 0.0 (-140 dBm) to 1.0 (-44 dBm)
    val fraction = (clamped - (-140)).toFloat() / ((-44) - (-140)).toFloat()

    val animatedFraction by animateFloatAsState(
        targetValue = fraction,
        animationSpec = tween(durationMillis = 600),
        label = "gauge_needle"
    )

    val (_, quality, qualityColorHex) = NetworkUtils.getSignalQuality(rsrpDbm)
    val qualityColor = Color(qualityColorHex)

    Box(
        modifier = modifier.size(240.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            val strokeWidth = 14.dp.toPx()
            val diameter = size.minDimension - strokeWidth
            val radius = diameter / 2f
            val centerOffset = Offset(size.width / 2f, size.height / 2f)
            val arcSize = Size(diameter, diameter)
            val topLeft = Offset(centerOffset.x - radius, centerOffset.y - radius)

            // Full sweep is 270 degrees, starting at 135 degrees (bottom left)
            val startAngle = 135f
            val totalSweep = 270f

            // Background track
            drawArc(
                color = Color(0x22FFFFFF),
                startAngle = startAngle,
                sweepAngle = totalSweep,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )

            // Segment 1: Red (-140 to -115 dBm) -> (25 / 96) * 270 = ~70.3°
            val sweep1 = (25f / 96f) * totalSweep
            drawArc(
                color = SignalRed,
                startAngle = startAngle,
                sweepAngle = sweep1,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Butt)
            )

            // Segment 2: Orange (-115 to -100 dBm) -> (15 / 96) * 270 = ~42.2°
            val sweep2 = (15f / 96f) * totalSweep
            drawArc(
                color = SignalOrange,
                startAngle = startAngle + sweep1,
                sweepAngle = sweep2,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Butt)
            )

            // Segment 3: Yellow (-100 to -85 dBm) -> (15 / 96) * 270 = ~42.2°
            val sweep3 = (15f / 96f) * totalSweep
            drawArc(
                color = SignalYellow,
                startAngle = startAngle + sweep1 + sweep2,
                sweepAngle = sweep3,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Butt)
            )

            // Segment 4: Green (-85 to -44 dBm) -> (41 / 96) * 270 = ~115.3°
            val sweep4 = (41f / 96f) * totalSweep
            drawArc(
                color = SignalGreen,
                startAngle = startAngle + sweep1 + sweep2 + sweep3,
                sweepAngle = sweep4,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )

            // Draw Tick marks
            for (i in 0..10) {
                val tickAngle = startAngle + (i / 10f) * totalSweep
                val rad = Math.toRadians(tickAngle.toDouble())
                val outerR = radius + (strokeWidth / 2) + 2.dp.toPx()
                val innerR = outerR - 8.dp.toPx()
                val p1 = Offset(
                    centerOffset.x + (innerR * cos(rad)).toFloat(),
                    centerOffset.y + (innerR * sin(rad)).toFloat()
                )
                val p2 = Offset(
                    centerOffset.x + (outerR * cos(rad)).toFloat(),
                    centerOffset.y + (outerR * sin(rad)).toFloat()
                )
                drawLine(
                    color = Color.White.copy(alpha = 0.5f),
                    start = p1,
                    end = p2,
                    strokeWidth = 2.dp.toPx()
                )
            }

            // Needle angle
            val needleAngle = startAngle + animatedFraction * totalSweep
            rotate(degrees = needleAngle - 270f, pivot = centerOffset) {
                // Needle line pointing up relative to rotation
                val needleLength = radius * 0.75f
                drawLine(
                    color = qualityColor,
                    start = centerOffset,
                    end = Offset(centerOffset.x, centerOffset.y + needleLength),
                    strokeWidth = 4.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }

            // Center pivot circle
            drawCircle(
                color = Color.White,
                radius = 8.dp.toPx(),
                center = centerOffset
            )
            drawCircle(
                color = qualityColor,
                radius = 5.dp.toPx(),
                center = centerOffset
            )
        }

        // Numerical readout in center bottom
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(top = 80.dp)
        ) {
            Text(
                text = "$rsrpDbm",
                style = MaterialTheme.typography.displaySmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = qualityColor
                )
            )
            Text(
                text = "dBm (RSRP)",
                style = MaterialTheme.typography.labelMedium.copy(
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 12.sp
                )
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = quality,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = qualityColor,
                    fontWeight = FontWeight.SemiBold
                )
            )
        }
    }
}
