package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.utils.NetworkUtils

/**
 * 5-bar animated cellular signal strength indicator.
 */
@Composable
fun SignalBarsIndicator(
    rsrpDbm: Int = -85,
    bars: Int? = null,
    modifier: Modifier = Modifier
) {
    val effectiveBars = bars ?: NetworkUtils.getSignalQuality(rsrpDbm).first
    val activeColor = when (effectiveBars) {
        5 -> Color(0xFF4CAF50)
        4 -> Color(0xFF8BC34A)
        3 -> Color(0xFFFFC107)
        2 -> Color(0xFFFF9800)
        else -> Color(0xFFF44336)
    }
    val inactiveColor = Color(0x33FFFFFF)

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.spacedBy(5.dp),
            modifier = Modifier.padding(vertical = 4.dp)
        ) {
            val heights = listOf(12.dp, 18.dp, 24.dp, 30.dp, 36.dp)

            for (index in 0 until 5) {
                val isActive = index < effectiveBars
                val barColor by animateColorAsState(
                    targetValue = if (isActive) activeColor else inactiveColor,
                    label = "barColor"
                )

                Box(
                    modifier = Modifier
                        .width(9.dp)
                        .height(heights[index])
                        .clip(RoundedCornerShape(3.dp))
                        .background(
                            if (isActive) barColor.copy(alpha = pulseAlpha) else barColor
                        )
                )
            }
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = "$effectiveBars / 5 أشرطة",
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = activeColor,
                fontSize = 11.sp
            )
        )
    }
}
