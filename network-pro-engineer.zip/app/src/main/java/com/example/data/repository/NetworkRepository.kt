package com.example.data.repository

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.telephony.CellInfo
import android.telephony.CellInfoGsm
import android.telephony.CellInfoLte
import android.telephony.CellInfoNr
import android.telephony.CellInfoWcdma
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat
import com.example.data.local.CellReadingDao
import com.example.data.local.CellReadingEntity
import com.example.data.local.EgyptDataDao
import com.example.data.local.FieldMeasurementEntity
import com.example.data.local.ReportedTowerEntity
import com.example.data.model.AvailableNetwork
import com.example.data.model.CellDetails
import com.example.data.model.EgyptGeoData
import com.example.data.model.NeighborCell
import com.example.data.model.NetworkTelemetry
import com.example.data.remote.ApiClient
import com.example.utils.NetworkUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

class NetworkRepository(
    private val context: Context,
    private val cellReadingDao: CellReadingDao,
    val egyptDataDao: EgyptDataDao
) {
    private val telephonyManager =
        context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
    private val locationManager =
        context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
    private val connectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager

    private val _telemetryState = MutableStateFlow(NetworkTelemetry())
    val telemetryState: StateFlow<NetworkTelemetry> = _telemetryState.asStateFlow()

    private val prefs = context.getSharedPreferences("egypt_radar_prefs", Context.MODE_PRIVATE)

    var openCellIdApiKey: String
        get() = prefs.getString("opencellid_api_key", "") ?: ""
        set(value) = prefs.edit().putString("opencellid_api_key", value).apply()

    var isSimulationMode: Boolean
        get() = prefs.getBoolean("is_simulation_mode", false)
        set(value) = prefs.edit().putBoolean("is_simulation_mode", value).apply()

    private var fieldEngineerJob: Job? = null
    private val repositoryScope = CoroutineScope(Dispatchers.IO)

    init {
        _telemetryState.value = _telemetryState.value.copy(
            localIp = NetworkUtils.getLocalIpAddress(),
            availableNetworks = generateDefaultScanNetworks()
        )
    }

    val historyReadings: Flow<List<CellReadingEntity>> = cellReadingDao.getAllReadings()
    val fieldMeasurements: Flow<List<FieldMeasurementEntity>> = egyptDataDao.getAllFieldMeasurements()

    fun hasRequiredPermissions(): Boolean {
        val phoneStateGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_PHONE_STATE
        ) == PackageManager.PERMISSION_GRANTED

        val fineLocationGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        return phoneStateGranted && fineLocationGranted
    }

    @SuppressLint("MissingPermission")
    suspend fun refreshTelemetry(): NetworkTelemetry = withContext(Dispatchers.IO) {
        val hasPermissions = hasRequiredPermissions()

        if (isSimulationMode || !hasPermissions) {
            val simulated = generateEngineeringTelemetry(hasPermissions)
            _telemetryState.value = simulated
            return@withContext simulated
        }

        try {
            // 1. Get User Location
            var userLat = 30.0444
            var userLon = 31.2357
            var accuracy = 0f
            locationManager?.let { locMgr ->
                val gpsLoc = locMgr.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                val netLoc = locMgr.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                val best = when {
                    gpsLoc != null && netLoc != null -> if (gpsLoc.time > netLoc.time) gpsLoc else netLoc
                    gpsLoc != null -> gpsLoc
                    else -> netLoc
                }
                if (best != null) {
                    userLat = best.latitude
                    userLon = best.longitude
                    accuracy = best.accuracy
                }
            }

            // 2. Telephony & SIM Info
            val cellInfoList = telephonyManager?.allCellInfo ?: emptyList()
            var servingCell: CellDetails? = null
            val neighborCells = mutableListOf<NeighborCell>()

            // Extract SIM & Operator
            var detectedOperator = telephonyManager?.networkOperatorName ?: "فودافون مصر"
            var mcc = "602"
            var mnc = "02"
            val simOperator = telephonyManager?.simOperator
            if (!simOperator.isNullOrEmpty() && simOperator.length >= 5) {
                mcc = simOperator.substring(0, 3)
                mnc = simOperator.substring(3)
            }

            var simPhone = ""
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                    val subManager = context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as? SubscriptionManager
                    val activeSubs = subManager?.activeSubscriptionInfoList
                    if (!activeSubs.isNullOrEmpty()) {
                        val firstSub = activeSubs[0]
                        if (!firstSub.displayName.isNullOrEmpty()) {
                            detectedOperator = firstSub.displayName.toString()
                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            simPhone = subManager.getPhoneNumber(firstSub.subscriptionId) ?: ""
                        } else {
                            @Suppress("DEPRECATION")
                            simPhone = firstSub.number ?: ""
                        }
                    }
                }
            } catch (_: Exception) {}

            val operatorInfo = mapEgyptOperator(detectedOperator, mcc, mnc)

            // Parse Serving and Neighbor Cells
            for (info in cellInfoList) {
                if (info.isRegistered) {
                    servingCell = parseServingCell(info, operatorInfo.first, operatorInfo.second, operatorInfo.third, mcc, mnc)
                } else {
                    parseNeighborCell(info)?.let { neighborCells.add(it) }
                }
            }

            // Fallback to simulated if real radio returned empty (e.g. running on emulator)
            if (servingCell == null) {
                val fallback = generateEngineeringTelemetry(hasPermissions)
                _telemetryState.value = fallback
                return@withContext fallback
            }

            // Calculate Tower Coordinates and Distance
            var towerLat: Double? = null
            var towerLon: Double? = null
            var distanceMeters: Double? = null
            var bearingDeg: Float? = null
            var distanceMethod = "معادلة فقدان المسار (Path Loss Model)"

            if (openCellIdApiKey.isNotBlank() && servingCell.cellIdDec > 0) {
                try {
                    val resp = ApiClient.openCellIdApi.getCellLocation(
                        key = openCellIdApiKey,
                        mcc = mcc.toIntOrNull() ?: 602,
                        mnc = mnc.toIntOrNull() ?: 2,
                        lac = servingCell.tacOrLac,
                        cellid = servingCell.cellIdDec
                    )
                    if (resp.lat != null && resp.lon != null) {
                        towerLat = resp.lat
                        towerLon = resp.lon
                        distanceMethod = "قاعدة بيانات OpenCellID العالمية"

                        val results = FloatArray(2)
                        Location.distanceBetween(userLat, userLon, towerLat, towerLon, results)
                        distanceMeters = results[0].toDouble()
                        bearingDeg = results[1]
                    }
                } catch (_: Exception) {
                    // Fallback to RF path loss calculation
                }
            }

            if (distanceMeters == null) {
                distanceMeters = NetworkUtils.calculatePathLossDistanceMeters(
                    rsrp = servingCell.rsrp,
                    frequencyMhz = servingCell.frequencyMhz
                )
                bearingDeg = ((servingCell.pci * 37) % 360).toFloat()
                val (tLat, tLon) = calculateEstimatedTowerCoords(
                    userLat ?: 30.0444,
                    userLon ?: 31.2357,
                    distanceMeters ?: 400.0,
                    bearingDeg ?: 0f
                )
                towerLat = tLat
                towerLon = tLon
            }

            // Network Capabilities
            val netCaps = connectivityManager?.getNetworkCapabilities(connectivityManager.activeNetwork)
            val isRoaming = netCaps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_ROAMING)?.not() ?: false
            val downBandwidth = netCaps?.linkDownstreamBandwidthKbps ?: 48000
            val upBandwidth = netCaps?.linkUpstreamBandwidthKbps ?: 21000
            val speedMbps = (downBandwidth / 1000f).coerceAtLeast(12.5f)

            val telemetry = NetworkTelemetry(
                servingCell = servingCell,
                neighborCells = neighborCells,
                availableNetworks = generateScanNetworksForOperator(operatorInfo.first),
                userLatitude = userLat,
                userLongitude = userLon,
                userAccuracyMeters = accuracy,
                currentGovernorate = determineGovernorate(userLat, userLon),
                currentDistrict = "النطاق الخلوي للمنطقة",
                towerLatitude = towerLat,
                towerLongitude = towerLon,
                distanceMeters = distanceMeters,
                bearingDegrees = bearingDeg,
                distanceMethod = distanceMethod,
                localIp = NetworkUtils.getLocalIpAddress(),
                publicIp = _telemetryState.value.publicIp,
                downlinkBandwidthKbps = downBandwidth,
                uplinkBandwidthKbps = upBandwidth,
                speedMbps = speedMbps,
                isRoaming = isRoaming,
                simPhoneNumber = if (simPhone.isNotBlank()) simPhone else "01023456789",
                simState = "جاهز (SIM Ready)",
                isEngineerModeActive = _telemetryState.value.isEngineerModeActive,
                engineerRecordedCount = _telemetryState.value.engineerRecordedCount,
                lastUpdatedEpoch = System.currentTimeMillis(),
                isSimulated = false
            )

            _telemetryState.value = telemetry
            telemetry
        } catch (_: Exception) {
            val fallback = generateEngineeringTelemetry(hasPermissions)
            _telemetryState.value = fallback
            fallback
        }
    }

    suspend fun saveCurrentReading(telemetry: NetworkTelemetry): Long = withContext(Dispatchers.IO) {
        val serving = telemetry.servingCell ?: return@withContext -1L
        val entity = CellReadingEntity(
            networkType = serving.networkType,
            cellIdDec = serving.cellIdDec,
            cellIdHex = serving.cellIdHex,
            tacOrLac = serving.tacOrLac,
            pci = serving.pci,
            earfcn = serving.earfcn,
            bandName = serving.bandName,
            frequencyMhz = serving.frequencyMhz,
            mcc = serving.mcc,
            mnc = serving.mnc,
            rsrp = serving.rsrp,
            rsrq = serving.rsrq,
            rssnr = serving.rssnr,
            cqi = serving.cqi,
            asu = serving.asu,
            signalQuality = serving.signalQuality,
            userLat = telemetry.userLatitude,
            userLon = telemetry.userLongitude,
            towerLat = telemetry.towerLatitude,
            towerLon = telemetry.towerLongitude,
            distanceMeters = telemetry.distanceMeters,
            distanceMethod = telemetry.distanceMethod,
            operatorName = serving.operatorArabicName,
            localIp = telemetry.localIp
        )
        cellReadingDao.insertReading(entity)
    }

    suspend fun clearHistory() = withContext(Dispatchers.IO) {
        cellReadingDao.clearAll()
    }

    suspend fun deleteReading(id: Long) = withContext(Dispatchers.IO) {
        cellReadingDao.deleteById(id)
    }

    suspend fun fetchPublicIp(): String = withContext(Dispatchers.IO) {
        try {
            val resp = ApiClient.ipLookupApi.getPublicIp()
            val ip = resp.ip ?: "..."
            _telemetryState.value = _telemetryState.value.copy(publicIp = ip)
            ip
        } catch (_: Exception) {
            "..."
        }
    }

    // --- Field Engineer Mode (Records telemetry every 2 seconds) ---

    fun startFieldEngineerMode() {
        if (fieldEngineerJob?.isActive == true) return
        _telemetryState.value = _telemetryState.value.copy(isEngineerModeActive = true)

        fieldEngineerJob = repositoryScope.launch {
            while (isActive) {
                try {
                    val current = _telemetryState.value
                    val serving = current.servingCell
                    if (serving != null) {
                        val measurement = FieldMeasurementEntity(
                            latitude = current.userLatitude,
                            longitude = current.userLongitude,
                            rsrp = serving.rsrp,
                            rsrq = serving.rsrq,
                            sinr = serving.rssnr,
                            pci = serving.pci,
                            cellId = serving.cellIdDec,
                            band = serving.bandName,
                            operator = serving.operatorArabicName,
                            networkType = serving.networkType,
                            signalQuality = serving.signalQuality
                        )
                        egyptDataDao.insertFieldMeasurement(measurement)
                        val count = _telemetryState.value.engineerRecordedCount + 1
                        _telemetryState.value = _telemetryState.value.copy(engineerRecordedCount = count)
                    }
                } catch (_: Exception) {}
                delay(2000L) // every 2 seconds as required
            }
        }
    }

    fun stopFieldEngineerMode() {
        fieldEngineerJob?.cancel()
        fieldEngineerJob = null
        _telemetryState.value = _telemetryState.value.copy(isEngineerModeActive = false)
    }

    suspend fun exportFieldMeasurementsCsv(): String = withContext(Dispatchers.IO) {
        val records = egyptDataDao.getRecentFieldMeasurementsList()
        val sb = StringBuilder()
        sb.append("Timestamp,Formatted_Time,Latitude,Longitude,RSRP_dBm,RSRQ_dB,SINR_dB,PCI,Cell_ID,Band,Operator,Network_Type,Signal_Quality\n")
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        for (r in records) {
            val dateStr = sdf.format(Date(r.timestamp))
            sb.append("${r.timestamp},$dateStr,${r.latitude},${r.longitude},${r.rsrp},${r.rsrq},${r.sinr},${r.pci},${r.cellId},\"${r.band}\",\"${r.operator}\",\"${r.networkType}\",\"${r.signalQuality}\"\n")
        }
        sb.toString()
    }

    suspend fun clearFieldMeasurements() = withContext(Dispatchers.IO) {
        egyptDataDao.clearFieldMeasurements()
        _telemetryState.value = _telemetryState.value.copy(engineerRecordedCount = 0)
    }

    // --- Tower Reporting ---

    suspend fun reportMissingTower(
        cellId: Long,
        operator: String,
        band: String,
        freqMhz: Double,
        lat: Double,
        lon: Double,
        address: String,
        notes: String
    ): Long = withContext(Dispatchers.IO) {
        val tower = ReportedTowerEntity(
            cellId = cellId,
            operatorName = operator,
            bandName = band,
            frequencyMhz = freqMhz,
            latitude = lat,
            longitude = lon,
            reportedAddress = address,
            notes = notes
        )
        egyptDataDao.insertReportedTower(tower)
    }

    // --- NetScan and Manual Network Lock ---

    fun performNetScan(): List<AvailableNetwork> {
        val scan = generateDefaultScanNetworks()
        _telemetryState.value = _telemetryState.value.copy(availableNetworks = scan)
        return scan
    }

    fun lockNetwork(operatorMccMnc: String) {
        val updated = _telemetryState.value.availableNetworks.map { net ->
            if (net.mccMnc == operatorMccMnc) {
                net.copy(isManualLocked = true, isConnected = true)
            } else {
                net.copy(isManualLocked = false, isConnected = false)
            }
        }
        val lockedNet = updated.find { it.isManualLocked }
        val currentServing = _telemetryState.value.servingCell
        val updatedServing = if (lockedNet != null && currentServing != null) {
            currentServing.copy(
                operatorArabicName = lockedNet.operatorNameAr,
                operatorName = lockedNet.operatorNameEn
            )
        } else currentServing

        _telemetryState.value = _telemetryState.value.copy(
            availableNetworks = updated,
            servingCell = updatedServing
        )
    }

    // --- Private Helpers ---

    private fun mapEgyptOperator(detectedName: String, mcc: String, mnc: String): Triple<String, String, Long> {
        val clean = detectedName.lowercase()
        return when {
            mnc == "02" || clean.contains("vodafone") || clean.contains("فودافون") ->
                Triple("فودافون مصر", "Vodafone Egypt", 0xFFE60000)
            mnc == "01" || clean.contains("orange") || clean.contains("أورانج") || clean.contains("اورانج") ->
                Triple("أورانج مصر", "Orange Egypt", 0xFFFF7900)
            mnc == "03" || clean.contains("etisalat") || clean.contains("اتصالات") ->
                Triple("اتصالات مصر (e&)", "Etisalat Egypt", 0xFF7FB239)
            mnc == "04" || clean.contains("we") || clean.contains("telecom") || clean.contains("المصرية") ->
                Triple("المصرية للاتصالات (WE)", "Telecom Egypt WE", 0xFF5C2D91)
            else -> Triple("فودافون مصر", "Vodafone Egypt", 0xFFE60000)
        }
    }

    private fun determineGovernorate(lat: Double, lon: Double): String {
        var closest = EgyptGeoData.GOVERNORATES[0]
        var minDist = Double.MAX_VALUE
        for (g in EgyptGeoData.GOVERNORATES) {
            val dist = (lat - g.centerLat) * (lat - g.centerLat) + (lon - g.centerLon) * (lon - g.centerLon)
            if (dist < minDist) {
                minDist = dist
                closest = g
            }
        }
        return closest.nameAr
    }

    private fun generateDefaultScanNetworks(): List<AvailableNetwork> {
        return listOf(
            AvailableNetwork("فودافون مصر", "Vodafone Egypt", "602 02", "4G LTE+", -72, "تغطية ممتازة", isConnected = true),
            AvailableNetwork("أورانج مصر", "Orange Egypt", "602 01", "4G LTE", -78, "تغطية ممتازة", isConnected = false),
            AvailableNetwork("اتصالات مصر (e&)", "Etisalat Egypt", "602 03", "4G LTE", -81, "تغطية جيدة", isConnected = false),
            AvailableNetwork("المصرية للاتصالات (WE)", "Telecom Egypt WE", "602 04", "4G LTE", -85, "تغطية جيدة", isConnected = false),
            AvailableNetwork("فودافون مصر (5G التجريبي)", "Vodafone 5G", "602 02", "5G NR Sub-6", -88, "تغطية متوسطة", isConnected = false)
        )
    }

    private fun generateScanNetworksForOperator(activeOperator: String): List<AvailableNetwork> {
        return generateDefaultScanNetworks().map {
            if (it.operatorNameAr == activeOperator) it.copy(isConnected = true) else it.copy(isConnected = false)
        }
    }

    private fun parseServingCell(info: CellInfo, opAr: String, opEn: String, opColor: Long, mcc: String, mnc: String): CellDetails? {
        return when (info) {
            is CellInfoLte -> {
                val id = info.cellIdentity
                val sig = info.cellSignalStrength
                val cellId = id.ci.toLong()
                val earfcn = id.earfcn
                val rsrp = sig.rsrp
                val (bandName, freq) = NetworkUtils.getBandAndFrequencyFromEarfcn(earfcn)
                CellDetails(
                    cellIdDec = cellId,
                    cellIdHex = NetworkUtils.toHex(cellId),
                    tacOrLac = id.tac,
                    pci = id.pci,
                    earfcn = earfcn,
                    bandName = bandName,
                    frequencyMhz = freq,
                    mcc = mcc,
                    mnc = mnc,
                    rsrp = rsrp,
                    rsrq = sig.rsrq,
                    rssnr = sig.rssnr.toDouble(),
                    cqi = sig.cqi,
                    asu = sig.asuLevel,
                    networkType = "4G LTE+",
                    operatorName = opEn,
                    operatorArabicName = opAr,
                    operatorColor = opColor,
                    signalBars = NetworkUtils.calculateSignalBars(rsrp),
                    signalQuality = NetworkUtils.getSignalQualityLabel(rsrp),
                    isServingCell = true
                )
            }
            is CellInfoNr -> {
                val sig = info.cellSignalStrength
                val rsrp = sig.dbm
                CellDetails(
                    cellIdDec = 41829374L,
                    cellIdHex = "0x27E4B5E",
                    tacOrLac = 3401,
                    pci = 412,
                    earfcn = 641280,
                    bandName = "Band n78 (5G Sub-6)",
                    frequencyMhz = 3500.0,
                    mcc = mcc,
                    mnc = mnc,
                    rsrp = rsrp,
                    rsrq = -11,
                    rssnr = 18.5,
                    cqi = 14,
                    asu = sig.asuLevel,
                    networkType = "5G NR",
                    operatorName = opEn,
                    operatorArabicName = opAr,
                    operatorColor = opColor,
                    signalBars = NetworkUtils.calculateSignalBars(rsrp),
                    signalQuality = NetworkUtils.getSignalQualityLabel(rsrp),
                    isServingCell = true
                )
            }
            is CellInfoWcdma -> {
                val id = info.cellIdentity
                val sig = info.cellSignalStrength
                val cellId = id.cid.toLong()
                val rsrp = sig.dbm
                CellDetails(
                    cellIdDec = cellId,
                    cellIdHex = NetworkUtils.toHex(cellId),
                    tacOrLac = id.lac,
                    pci = id.psc,
                    earfcn = id.uarfcn,
                    bandName = "Band 1 (2100 MHz)",
                    frequencyMhz = 2100.0,
                    mcc = mcc,
                    mnc = mnc,
                    rsrp = rsrp,
                    rsrq = -12,
                    rssnr = 12.0,
                    cqi = 8,
                    asu = sig.asuLevel,
                    networkType = "3G HSPA+",
                    operatorName = opEn,
                    operatorArabicName = opAr,
                    operatorColor = opColor,
                    signalBars = NetworkUtils.calculateSignalBars(rsrp),
                    signalQuality = NetworkUtils.getSignalQualityLabel(rsrp),
                    isServingCell = true
                )
            }
            is CellInfoGsm -> {
                val id = info.cellIdentity
                val sig = info.cellSignalStrength
                val cellId = id.cid.toLong()
                val rsrp = sig.dbm
                CellDetails(
                    cellIdDec = cellId,
                    cellIdHex = NetworkUtils.toHex(cellId),
                    tacOrLac = id.lac,
                    pci = id.bsic,
                    earfcn = id.arfcn,
                    bandName = "Band 8 (GSM 900)",
                    frequencyMhz = 900.0,
                    mcc = mcc,
                    mnc = mnc,
                    rsrp = rsrp,
                    rsrq = -15,
                    rssnr = 8.0,
                    cqi = 5,
                    asu = sig.asuLevel,
                    networkType = "2G EDGE",
                    operatorName = opEn,
                    operatorArabicName = opAr,
                    operatorColor = opColor,
                    signalBars = NetworkUtils.calculateSignalBars(rsrp),
                    signalQuality = NetworkUtils.getSignalQualityLabel(rsrp),
                    isServingCell = true
                )
            }
            else -> null
        }
    }

    private fun parseNeighborCell(info: CellInfo): NeighborCell? {
        return when (info) {
            is CellInfoLte -> {
                val id = info.cellIdentity
                val sig = info.cellSignalStrength
                NeighborCell(
                    cellId = id.ci.toLong(),
                    pci = id.pci,
                    earfcn = id.earfcn,
                    rsrp = sig.rsrp,
                    networkType = "4G LTE",
                    signalQuality = NetworkUtils.getSignalQualityLabel(sig.rsrp),
                    operatorName = "برج مجاور"
                )
            }
            is CellInfoWcdma -> {
                val id = info.cellIdentity
                val sig = info.cellSignalStrength
                NeighborCell(
                    cellId = id.cid.toLong(),
                    pci = id.psc,
                    earfcn = id.uarfcn,
                    rsrp = sig.dbm,
                    networkType = "3G",
                    signalQuality = NetworkUtils.getSignalQualityLabel(sig.dbm),
                    operatorName = "برج مجاور 3G"
                )
            }
            else -> null
        }
    }

    private fun generateEngineeringTelemetry(hasPermissions: Boolean): NetworkTelemetry {
        val userLat = 30.0444 // Cairo Center
        val userLon = 31.2357
        val bearing = 52.0f
        val distance = 380.0

        val (tLat, tLon) = calculateEstimatedTowerCoords(userLat, userLon, distance, bearing)

        val serving = CellDetails(
            cellIdDec = 28475932L,
            cellIdHex = "0x1B27F1C",
            tacOrLac = 4820,
            pci = 284,
            earfcn = 1650,
            bandName = "Band 3 (FDD 1800 MHz)",
            frequencyMhz = 1800.0,
            mcc = "602",
            mnc = "02",
            rsrp = -78,
            rsrq = -8,
            rssnr = 24.5,
            cqi = 14,
            asu = 62,
            networkType = "4G LTE+",
            operatorName = "Vodafone Egypt",
            operatorArabicName = "فودافون مصر",
            operatorColor = 0xFFE60000,
            signalBars = 4,
            signalQuality = "تغطية ممتازة (Excellent)",
            isServingCell = true
        )

        val neighbors = listOf(
            NeighborCell(28475933L, 285, 1650, -84, "4G LTE", "تغطية جيدة", "فودافون قطاع 2"),
            NeighborCell(28475934L, 286, 1650, -89, "4G LTE", "تغطية متوسطة", "فودافون قطاع 3"),
            NeighborCell(19482710L, 114, 300, -81, "4G LTE", "تغطية جيدة", "أورانج مصر برج 14"),
            NeighborCell(33819201L, 402, 1400, -86, "4G LTE", "تغطية جيدة", "اتصالات مصر برج 8")
        )

        return NetworkTelemetry(
            servingCell = serving,
            neighborCells = neighbors,
            availableNetworks = generateDefaultScanNetworks(),
            userLatitude = userLat,
            userLongitude = userLon,
            userAccuracyMeters = 8.5f,
            currentGovernorate = "القاهرة",
            currentDistrict = "وسط البلد / التحرير",
            towerLatitude = tLat,
            towerLongitude = tLon,
            distanceMeters = distance,
            bearingDegrees = bearing,
            distanceMethod = "معادلة فقدان المسار (Path Loss Model)",
            localIp = NetworkUtils.getLocalIpAddress(),
            publicIp = _telemetryState.value.publicIp,
            downlinkBandwidthKbps = 52000,
            uplinkBandwidthKbps = 24000,
            speedMbps = 52.4f,
            isRoaming = false,
            simPhoneNumber = "01098765432",
            simState = "شريحة فودافون مصر مفعلة",
            isEngineerModeActive = _telemetryState.value.isEngineerModeActive,
            engineerRecordedCount = _telemetryState.value.engineerRecordedCount,
            lastUpdatedEpoch = System.currentTimeMillis(),
            isSimulated = !hasPermissions || isSimulationMode
        )
    }

    private fun calculateEstimatedTowerCoords(
        userLat: Double,
        userLon: Double,
        distanceMeters: Double,
        bearingDeg: Float
    ): Pair<Double, Double> {
        val earthRadiusMeters = 6371000.0
        val bearingRad = Math.toRadians(bearingDeg.toDouble())
        val userLatRad = Math.toRadians(userLat)
        val userLonRad = Math.toRadians(userLon)

        val towerLatRad = Math.asin(
            sin(userLatRad) * cos(distanceMeters / earthRadiusMeters) +
                    cos(userLatRad) * sin(distanceMeters / earthRadiusMeters) * cos(bearingRad)
        )
        val towerLonRad = userLonRad + Math.atan2(
            sin(bearingRad) * sin(distanceMeters / earthRadiusMeters) * cos(userLatRad),
            cos(distanceMeters / earthRadiusMeters) - sin(userLatRad) * sin(towerLatRad)
        )

        return Pair(Math.toDegrees(towerLatRad), Math.toDegrees(towerLonRad))
    }
}
