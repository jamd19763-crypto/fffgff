package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface EgyptDataDao {

    // Governorates
    @Query("SELECT * FROM governorates ORDER BY id ASC")
    fun getAllGovernorates(): Flow<List<GovernorateEntity>>

    @Query("SELECT * FROM governorates WHERE id = :id LIMIT 1")
    suspend fun getGovernorateById(id: Int): GovernorateEntity?

    @Query("SELECT * FROM governorates WHERE nameAr LIKE '%' || :query || '%' OR nameEn LIKE '%' || :query || '%' OR topDistrictsCsv LIKE '%' || :query || '%'")
    fun searchGovernorates(query: String): Flow<List<GovernorateEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGovernorates(list: List<GovernorateEntity>)

    @Query("SELECT COUNT(*) FROM governorates")
    suspend fun getGovernoratesCount(): Int

    // Districts
    @Query("SELECT * FROM districts WHERE govId = :govId ORDER BY nameAr ASC")
    fun getDistrictsByGov(govId: Int): Flow<List<DistrictEntity>>

    @Query("SELECT * FROM districts WHERE nameAr LIKE '%' || :query || '%'")
    fun searchDistricts(query: String): Flow<List<DistrictEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDistricts(list: List<DistrictEntity>)

    // Number Lookups History
    @Query("SELECT * FROM number_lookups ORDER BY lookupTimestamp DESC")
    fun getNumberLookups(): Flow<List<NumberLookupEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNumberLookup(item: NumberLookupEntity): Long

    @Query("DELETE FROM number_lookups WHERE id = :id")
    suspend fun deleteNumberLookup(id: Long)

    @Query("DELETE FROM number_lookups")
    suspend fun clearNumberLookups()

    // Field Measurements (Field Engineer Mode)
    @Query("SELECT * FROM field_measurements ORDER BY timestamp DESC")
    fun getAllFieldMeasurements(): Flow<List<FieldMeasurementEntity>>

    @Query("SELECT * FROM field_measurements ORDER BY timestamp DESC LIMIT 200")
    suspend fun getRecentFieldMeasurementsList(): List<FieldMeasurementEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFieldMeasurement(item: FieldMeasurementEntity): Long

    @Query("DELETE FROM field_measurements")
    suspend fun clearFieldMeasurements()

    @Query("SELECT COUNT(*) FROM field_measurements")
    fun getFieldMeasurementsCount(): Flow<Int>

    // Reported Towers
    @Query("SELECT * FROM reported_towers ORDER BY timestamp DESC")
    fun getAllReportedTowers(): Flow<List<ReportedTowerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReportedTower(tower: ReportedTowerEntity): Long
}
