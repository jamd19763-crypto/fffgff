package com.example.data.model

/**
 * Detailed representation of a cellular base station / serving cell.
 */
data class CellDetails(
    val cellIdDec: Long,
    val cellIdHex: String,
    val tacOrLac: Int,
    val pci: Int,
    val earfcn: Int,
    val bandName: String,
    val frequencyMhz: Double,
    val mcc: String,
    val mnc: String,
    val rsrp: Int,
    val rsrq: Int,
    val rssnr: Double,
    val cqi: Int,
    val asu: Int,
    val networkType: String,
    val operatorName: String,
    val operatorArabicName: String = "فودافون مصر",
    val operatorColor: Long = 0xFFE60000,
    val signalBars: Int,
    val signalQuality: String,
    val isServingCell: Boolean = true
)

/**
 * Neighboring cell information detected by the radio interface.
 */
data class NeighborCell(
    val cellId: Long,
    val pci: Int,
    val earfcn: Int,
    val rsrp: Int,
    val networkType: String,
    val signalQuality: String,
    val operatorName: String = "مشغل مجاور"
)

/**
 * Result of NetScan (Available networks scan).
 */
data class AvailableNetwork(
    val operatorNameAr: String,
    val operatorNameEn: String,
    val mccMnc: String,
    val networkType: String,
    val signalDbm: Int,
    val signalQuality: String,
    val isConnected: Boolean = false,
    val isManualLocked: Boolean = false
)

/**
 * Full aggregated snapshot of network and tower telemetry.
 */
data class NetworkTelemetry(
    val servingCell: CellDetails? = null,
    val neighborCells: List<NeighborCell> = emptyList(),
    val availableNetworks: List<AvailableNetwork> = emptyList(),
    val userLatitude: Double = 30.0444, // Cairo default
    val userLongitude: Double = 31.2357,
    val userAccuracyMeters: Float = 0f,
    val currentGovernorate: String = "القاهرة",
    val currentDistrict: String = "وسط البلد",
    val towerLatitude: Double? = null,
    val towerLongitude: Double? = null,
    val distanceMeters: Double? = null,
    val bearingDegrees: Float? = null,
    val distanceMethod: String = "معادلة فقدان المسار (Path Loss)",
    val localIp: String = "192.168.1.105",
    val publicIp: String = "...",
    val downlinkBandwidthKbps: Int = 45000,
    val uplinkBandwidthKbps: Int = 18000,
    val speedMbps: Float = 45.2f,
    val isRoaming: Boolean = false,
    val simPhoneNumber: String = "01098765432",
    val simState: String = "شريحة SIM مفعلة ونشطة",
    val isEngineerModeActive: Boolean = false,
    val engineerRecordedCount: Int = 0,
    val lastUpdatedEpoch: Long = System.currentTimeMillis(),
    val isSimulated: Boolean = false
)
