package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface CellReadingDao {

    @Query("SELECT * FROM cell_readings ORDER BY timestamp DESC")
    fun getAllReadings(): Flow<List<CellReadingEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReading(reading: CellReadingEntity): Long

    @Query("DELETE FROM cell_readings WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM cell_readings")
    suspend fun clearAll()

    @Query("SELECT COUNT(*) FROM cell_readings")
    fun getCount(): Flow<Int>
}
