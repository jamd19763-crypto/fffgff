package com.example.data.remote

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class OpenCellIdResponse(
    @Json(name = "status") val status: String? = null,
    @Json(name = "message") val message: String? = null,
    @Json(name = "lat") val lat: Double? = null,
    @Json(name = "lon") val lon: Double? = null,
    @Json(name = "mcc") val mcc: Int? = null,
    @Json(name = "mnc") val mnc: Int? = null,
    @Json(name = "lac") val lac: Int? = null,
    @Json(name = "cellid") val cellid: Long? = null,
    @Json(name = "range") val range: Long? = null,
    @Json(name = "samples") val samples: Int? = null
)

@JsonClass(generateAdapter = true)
data class IpifyResponse(
    @Json(name = "ip") val ip: String? = null
)

interface OpenCellIdApi {
    @GET("cell/get")
    suspend fun getCellLocation(
        @Query("key") key: String,
        @Query("mcc") mcc: Int,
        @Query("mnc") mnc: Int,
        @Query("lac") lac: Int,
        @Query("cellid") cellid: Long,
        @Query("format") format: String = "json"
    ): OpenCellIdResponse
}

interface IpLookupApi {
    @GET("?format=json")
    suspend fun getPublicIp(): IpifyResponse
}

object ApiClient {
    private val okHttpClient: OkHttpClient by lazy {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }
        OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .addInterceptor(logging)
            .build()
    }

    private val moshi: Moshi by lazy {
        Moshi.Builder()
            .add(KotlinJsonAdapterFactory())
            .build()
    }

    val openCellIdApi: OpenCellIdApi by lazy {
        Retrofit.Builder()
            .baseUrl("https://opencellid.org/")
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(OpenCellIdApi::class.java)
    }

    val ipLookupApi: IpLookupApi by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.ipify.org/")
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(IpLookupApi::class.java)
    }
}
