package com.example.utils

import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

object NetworkUtils {

    fun toHex(value: Long): String = "0x" + value.toString(16).uppercase(Locale.US)

    fun calculatePathLossDistanceMeters(rsrp: Int, frequencyMhz: Double): Double =
        estimateDistanceByPathLoss(rsrp, frequencyMhz)

    fun getBandAndFrequencyFromEarfcn(earfcn: Int): Pair<String, Double> =
        calculateBandFromEarfcn(earfcn)

    fun calculateSignalBars(rsrp: Int): Int = getSignalQuality(rsrp).first

    fun getSignalQualityLabel(rsrp: Int): String = getSignalQuality(rsrp).second

    fun formatDistance(meters: Double?): String = formatDistanceArabic(meters)

    /**
     * Converts an LTE EARFCN to its 3GPP Band name and Downlink Frequency in MHz.
     */
    fun calculateBandFromEarfcn(earfcn: Int): Pair<String, Double> {
        return when {
            earfcn in 0..599 -> Pair("Band 1 (2100 FDD)", 2110.0 + 0.1 * (earfcn - 0))
            earfcn in 600..1199 -> Pair("Band 2 (1900 FDD)", 1930.0 + 0.1 * (earfcn - 600))
            earfcn in 1200..1949 -> Pair("Band 3 (1800 FDD)", 1805.0 + 0.1 * (earfcn - 1200))
            earfcn in 1950..2399 -> Pair("Band 4 (AWS-1)", 2110.0 + 0.1 * (earfcn - 1950))
            earfcn in 2400..2649 -> Pair("Band 5 (850 FDD)", 869.0 + 0.1 * (earfcn - 2400))
            earfcn in 2750..3449 -> Pair("Band 7 (2600 FDD)", 2620.0 + 0.1 * (earfcn - 2750))
            earfcn in 3450..3799 -> Pair("Band 8 (900 FDD)", 925.0 + 0.1 * (earfcn - 3450))
            earfcn in 6150..6599 -> Pair("Band 20 (800 DD)", 791.0 + 0.1 * (earfcn - 6150))
            earfcn in 9210..9659 -> Pair("Band 28 (700 APT)", 758.0 + 0.1 * (earfcn - 9210))
            earfcn in 37750..38249 -> Pair("Band 38 (2600 TDD)", 2570.0 + 0.1 * (earfcn - 37750))
            earfcn in 38250..38649 -> Pair("Band 39 (1900 TDD)", 1880.0 + 0.1 * (earfcn - 38250))
            earfcn in 38650..39649 -> Pair("Band 40 (2300 TDD)", 2300.0 + 0.1 * (earfcn - 38650))
            earfcn in 39650..41589 -> Pair("Band 41 (2500 TDD)", 2496.0 + 0.1 * (earfcn - 39650))
            earfcn in 41590..43589 -> Pair("Band 42 (3500 TDD)", 3400.0 + 0.1 * (earfcn - 41590))
            earfcn in 43590..45589 -> Pair("Band 43 (3700 TDD)", 3600.0 + 0.1 * (earfcn - 43590))
            earfcn in 46590..46789 -> Pair("Band 48 (CBRS)", 3550.0 + 0.1 * (earfcn - 46590))
            earfcn in 65536..66435 -> Pair("Band 66 (Extended AWS)", 2110.0 + 0.1 * (earfcn - 65536))
            earfcn in 68586..69085 -> Pair("Band 71 (600 MHz)", 617.0 + 0.1 * (earfcn - 68586))
            else -> Pair("Band غير محدد", 1800.0)
        }
    }

    /**
     * Converts a 5G NR-ARFCN to its 3GPP Band name and Frequency in MHz.
     */
    fun calculateNrBand(nrArfcn: Int): Pair<String, Double> {
        return when {
            nrArfcn in 123400..130400 -> Pair("n71 (600 MHz)", 617.0 + 0.05 * (nrArfcn - 123400))
            nrArfcn in 140000..149000 -> Pair("n28 (700 MHz)", 758.0 + 0.05 * (nrArfcn - 140000))
            nrArfcn in 151600..160600 -> Pair("n20 (800 MHz)", 791.0 + 0.05 * (nrArfcn - 151600))
            nrArfcn in 422000..434000 -> Pair("n1 (2100 MHz)", 2110.0 + 0.05 * (nrArfcn - 422000))
            nrArfcn in 361000..376000 -> Pair("n3 (1800 MHz)", 1805.0 + 0.05 * (nrArfcn - 361000))
            nrArfcn in 524000..538000 -> Pair("n7 (2600 MHz)", 2620.0 + 0.05 * (nrArfcn - 524000))
            nrArfcn in 499200..537999 -> Pair("n41 (2.5 GHz TDD)", 2496.0 + 0.015 * (nrArfcn - 499200))
            nrArfcn in 620000..680000 -> Pair("n78 (3.5 GHz C-Band)", 3300.0 + 0.015 * (nrArfcn - 620000))
            nrArfcn in 693334..733333 -> Pair("n77 (3.7 GHz C-Band)", 3700.0 + 0.015 * (nrArfcn - 693334))
            else -> Pair("5G NR Band", 3500.0)
        }
    }

    /**
     * Calculates the great-circle distance between two geographic coordinates using the Haversine formula.
     * Returns distance in meters.
     */
    fun haversineDistanceMeters(
        lat1: Double,
        lon1: Double,
        lat2: Double,
        lon2: Double
    ): Double {
        val r = 6371000.0 // Earth's mean radius in meters
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                sin(dLon / 2).pow(2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return r * c
    }

    /**
     * Calculates the initial bearing (forward azimuth) from point 1 to point 2 in degrees (0..360).
     */
    fun calculateBearing(
        lat1: Double,
        lon1: Double,
        lat2: Double,
        lon2: Double
    ): Float {
        val phi1 = Math.toRadians(lat1)
        val phi2 = Math.toRadians(lat2)
        val deltaLambda = Math.toRadians(lon2 - lon1)

        val y = sin(deltaLambda) * cos(phi2)
        val x = cos(phi1) * sin(phi2) - sin(phi1) * cos(phi2) * cos(deltaLambda)
        val theta = atan2(y, x)
        val bearing = (Math.toDegrees(theta) + 360.0) % 360.0
        return bearing.toFloat()
    }

    /**
     * Converts a bearing angle in degrees to an Arabic compass direction.
     */
    fun bearingToCompassArabic(bearing: Float): String {
        val normalized = (bearing % 360 + 360) % 360
        val degStr = String.format(Locale.US, "%.0f°", normalized)
        return when {
            normalized in 337.5..360.0 || normalized < 22.5 -> "شمال ($degStr)"
            normalized in 22.5..67.5 -> "شمال شرق ($degStr)"
            normalized in 67.5..112.5 -> "شرق ($degStr)"
            normalized in 112.5..157.5 -> "جنوب شرق ($degStr)"
            normalized in 157.5..202.5 -> "جنوب ($degStr)"
            normalized in 202.5..247.5 -> "جنوب غرب ($degStr)"
            normalized in 247.5..292.5 -> "غرب ($degStr)"
            normalized in 292.5..337.5 -> "شمال غرب ($degStr)"
            else -> "$degStr"
        }
    }

    /**
     * Estimates distance from the cell tower in meters based on the RF Path Loss Model:
     * PL(d) = TxPower (e.g. 43 dBm) + AntennaGain (15 dBi) - RSRP - RxGain (0 dBi)
     * Using Log-Distance Path Loss Model in suburban/urban cellular propagation.
     * FSPL(d0=100m, f) + 10 * n * log10(d / d0)
     */
    fun estimateDistanceByPathLoss(rsrpDbm: Int, frequencyMhz: Double): Double {
        val validRsrp = if (rsrpDbm in -145..-40) rsrpDbm else -95
        val validFreq = if (frequencyMhz > 400.0) frequencyMhz else 1800.0

        // Base station typical EIRP = 43 dBm (Tx) + 15 dBi (Antenna) = 58 dBm
        // Resource Element power = Total EIRP - 10*log10(1200 subcarriers) ≈ 58 - 30.8 = 27.2 dBm
        val txPowerPerRe = 27.0
        val pathLoss = txPowerPerRe - validRsrp // Path loss in dB

        // Path Loss exponent 'n': 2.0 in free space, 2.7 in suburban, 3.5 in dense urban
        val n = 3.2
        // Reference distance d0 = 100 meters
        val d0 = 100.0
        // FSPL at 100m = 20*log10(d0) + 20*log10(f_MHz) - 27.55
        // (d in meters, f in MHz)
        val plAtD0 = 20.0 * log10(d0) + 20.0 * log10(validFreq) - 27.55

        val exponent = (pathLoss - plAtD0) / (10.0 * n)
        val distance = d0 * 10.0.pow(exponent)

        // Clamp to sensible physical boundaries (50m to 15,000m)
        return distance.coerceIn(50.0, 15000.0)
    }

    /**
     * Formats distance nicely in Arabic (e.g. "450 متر" or "1.85 كم").
     */
    fun formatDistanceArabic(meters: Double?): String {
        if (meters == null || meters.isNaN() || meters <= 0) return "غير متوفر"
        return if (meters >= 1000.0) {
            String.format(Locale.US, "%.2f كم", meters / 1000.0)
        } else {
            String.format(Locale.US, "%d متر", meters.roundToInt())
        }
    }

    /**
     * Gets the local device IPv4 address from network interfaces.
     */
    fun getLocalIpAddress(): String {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val networkInterface = interfaces.nextElement()
                val addresses = networkInterface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val address = addresses.nextElement()
                    if (!address.isLoopbackAddress && address is Inet4Address) {
                        return address.hostAddress ?: "127.0.0.1"
                    }
                }
            }
        } catch (_: Exception) {
        }
        return "127.0.0.1"
    }

    /**
     * Formats a Long Cell ID to decimal and hexadecimal representations.
     */
    fun formatCellId(cellId: Long): Pair<String, String> {
        val dec = cellId.toString()
        val hex = "0x" + cellId.toString(16).uppercase(Locale.US)
        return Pair(dec, hex)
    }

    /**
     * Maps RSRP in dBm to a 5-bar signal strength and Arabic quality label.
     */
    fun getSignalQuality(rsrp: Int): Triple<Int, String, Long> {
        return when {
            rsrp >= -80 -> Triple(5, "ممتاز (Excellent)", 0xFF4CAF50)
            rsrp >= -90 -> Triple(4, "جيد (Good)", 0xFF8BC34A)
            rsrp >= -100 -> Triple(3, "متوسط (Fair)", 0xFFFFC107)
            rsrp >= -115 -> Triple(2, "ضعيف (Poor)", 0xFFFF9800)
            else -> Triple(1, "حرج (Very Poor)", 0xFFF44336)
        }
    }
}
