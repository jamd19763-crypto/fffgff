package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.utils.NetworkUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("رادار الشبكة والأبراج", appName)
    }

    @Test
    fun `test haversine distance calculation`() {
        // Riyadh tower sector distance test
        val dist = NetworkUtils.haversineDistanceMeters(24.7136, 46.6753, 24.7160, 46.6780)
        assertTrue("Distance should be approximately 370-400 meters", dist in 350.0..450.0)
    }

    @Test
    fun `test earfcn to band conversion`() {
        val (band1, freq1) = NetworkUtils.calculateBandFromEarfcn(1650)
        assertEquals("Band 3 (1800 FDD)", band1)
        assertEquals(1850.0, freq1, 0.1)

        val (band7, _) = NetworkUtils.calculateBandFromEarfcn(3100)
        assertEquals("Band 7 (2600 FDD)", band7)
    }

    @Test
    fun `test path loss distance estimation`() {
        val dist = NetworkUtils.estimateDistanceByPathLoss(-78, 1800.0)
        assertTrue("Estimated distance should be valid positive number", dist > 50.0 && dist < 5000.0)
    }
}
